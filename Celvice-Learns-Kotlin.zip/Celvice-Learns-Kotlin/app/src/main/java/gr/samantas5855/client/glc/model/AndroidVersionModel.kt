package gr.samantas5855.client.glc.model

class  AndroidVersionModel(imgResId: Int, matchTeams: String, championshipName: String, soundLang: String, matchTime: String) {
    var imgResId : Int? = imgResId
    var matchTeams: String? = matchTeams
    var championshipName: String? = championshipName
    var soundLang: String? = soundLang
    var matchTime: String? = matchTime

}
